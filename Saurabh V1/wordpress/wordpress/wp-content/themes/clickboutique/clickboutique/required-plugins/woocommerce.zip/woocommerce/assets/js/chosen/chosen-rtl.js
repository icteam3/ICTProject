jQuery(function($) {

	// Fix Chosen for RTL
	$('.chosen_select, .chosen_select_nostd, .product_attributes select.multiselect, select.country_select, select.state_select, select#dropdown_shop_coupon_type, select[name=m]').addClass('chosen-rtl');

});
