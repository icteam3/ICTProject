# Lite Social Sharing Buttons

## A Simple WordPress plugin

This is a light-weight, high-DPI-ready, icon-font-utilizing, rudimentary WordPress plugin which adds a set of Sharing buttons to the bottom of your post and pages.

## License

The plugin is [MIT licensed](http://opensource.org/licenses/MIT), though the [Entypo pictogram font](http://www.entypo.com) by Daniel Bruce is under the [SIL Open Font License](http://opensource.org/licenses/OFL-1.1). Both are considered GPL-compatible by the FSF.
